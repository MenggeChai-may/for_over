# gcn-demo
Semi-Supervised classification with Graph Convolution Networks using Pytorch


Paper:https://arxiv.org/pdf/1609.02907.pdf

My implementation of the paper on a demo dataset(karate club), using pytorch
