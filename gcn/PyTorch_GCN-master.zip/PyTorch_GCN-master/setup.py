from setuptools import setup

setup(
        name='PyTorch_GCN',
        version='0.1',
        packages=[''],
        url='https://github.com/chengsen/PyTorch_GCN',
        license='',
        author='chengsen',
        author_email='singsam_jam@126.com',
        description=''
)
